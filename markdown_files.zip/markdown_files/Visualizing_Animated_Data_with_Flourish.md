---title: Visualizing Animated Data with Flourishoriginal_url: https://tds.s-anand.net/#/visualizing-animated-data-with-flourish?id=visualizing-animated-data-with-flourishdownloaded_at: 2025-06-08T21:12:18.283428---[Visualizing Animated Data with Flourish](#/visualizing-animated-data-with-flourish?id=visualizing-animated-data-with-flourish)
-------------------------------------------------------------------------------------------------------------------------------

[![Visualizing animated data with Flourish](https://i.ytimg.com/vi_webp/JrnIu5Bm8i4/sddefault.webp)](https://youtu.be/JrnIu5Bm8i4)

[Previous

Visualizing Animated Data with PowerPoint](#/visualizing-animated-data-with-powerpoint)

[Next

Visualizing Network Data with Kumu](#/visualizing-network-data-with-kumu)